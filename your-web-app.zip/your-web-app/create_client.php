<?php
include('includes/db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the POST request
    $name = $_POST['name']; //  attribute of your input field
    // Add more fields as needed

    // Perform validation if necessary

    // Insert new client into the database
    $sql = "INSERT INTO clients (Name) VALUES ('$name')"; // 'clients' is your clients table
    if ($conn->query($sql) === TRUE) {
        echo "New client created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Invalid request method for creating a new client";
}

$conn->close();
?>

