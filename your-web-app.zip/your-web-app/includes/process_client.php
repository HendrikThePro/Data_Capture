<?php

include('includes/db.php');



// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $clientName = $_POST["name"];
    saveClient($conn, $clientName);
    echo "Client saved successfully!";
} else {
    echo "Invalid request!";
}

$conn->close();

function saveClient($conn, $name) {
    $stmt = $conn->prepare("INSERT INTO clients (name) VALUES (?)");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $stmt->close();
}
?>

