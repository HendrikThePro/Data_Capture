<?php
include 'db.php';
include('includes/db.php');
include 'client_list.php';
include 'subdirectory/client_list.php';
include __DIR__ . '/client_list.php';
include __DIR__ . DIRECTORY_SEPARATOR . 'client_list.php';


// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $clientName = $_POST["name"];
    saveClient($conn, $clientName);
    echo "Client saved successfully!";
} else {
    echo "Invalid request!";
}

$conn->close();

function saveClient($conn, $name) {
    $stmt = $conn->prepare("INSERT INTO clients (name) VALUES (?)");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $stmt->close();
}
?>

