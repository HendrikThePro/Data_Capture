<?php
include('includes/db.php');


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the form data and insert into the database
    $name = $_POST['name'];
    
    $sql = "INSERT INTO clients (Name) VALUES ('$name')";

    if ($conn->query($sql) === TRUE) {
        echo "New client created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "No contacts found";
}

$conn->close();
?>
