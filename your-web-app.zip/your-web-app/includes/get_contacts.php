<!-- get_contacts.php -->
<?php
// Placeholder script - Replace with actual logic to fetch contacts

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";

// Establishing database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch contacts (replace with your actual query)
$sql = "SELECT * FROM contacts";
$result = $conn->query($sql);

// Display contacts or "No contacts found" if the result is empty
if ($result && $result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>Name</th><th>Surname</th><th>Email</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['name']}</td>";
        echo "<td>{$row['surname']}</td>";
        echo "<td>{$row['email']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No contacts found.";
}

// Close the database connection
$conn->close();
?>


