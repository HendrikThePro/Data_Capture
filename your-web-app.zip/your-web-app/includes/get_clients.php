<!-- get_clients.php -->
<?php

// Fetch clients (replace with your actual query)
$sql = "SELECT * FROM clients ORDER BY name ASC";
$result = $conn->query($sql);

// Display clients or "No clients found" if the result is empty
if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>Name</th><th>Client Code</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['name']}</td>";
        echo "<td>{$row['client_code']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No clients found.";
}

$conn->close();
?>




function generateClientCode($name) {
    // Remove spaces and make the name uppercase
    $cleanedName = strtoupper(str_replace(' ', '', $name));

    // Take the first three characters of the name
    $shortName = substr($cleanedName, 0, 3);

    // Generate a random three-digit number
    $randomNumber = rand(100, 999);

    // Combine the short name and random number to form the client code
    $clientCode = $shortName . $randomNumber;

    return $clientCode;
}


// Example usage:
$clientName = "Example Client";
$clientCode = generateClientCode($clientName);
echo "Generated Client Code for '$clientName': $clientCode";
?>

function getLinkedContactsCount($clientId) {
    // logic to get the number of linked contacts for a client
    // 
    return rand(0, 10);
}
?>
