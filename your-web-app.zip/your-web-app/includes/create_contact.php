<?php
include('includes/db.php');


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the POST request
    $name = $_POST['name']; // 'name' with the actual name attribute of your input field
    // Add more fields as needed

    // Perform validation if necessary

    // Insert new contact into the database
    $sql = "INSERT INTO contacts (Name) VALUES ('$name')"; // Assuming 'contacts' is your contacts table
    if ($conn->query($sql) === TRUE) {
        echo "New contact created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Invalid request method for creating a new contact";
}

$conn->close();
?>
