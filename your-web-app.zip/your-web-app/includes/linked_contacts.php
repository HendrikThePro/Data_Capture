<?php
include('includes/db.php');



if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['client_id'])) {
    // Fetch and display linked contacts for the specified client
    $client_id = $_GET['client_id'];

    $sql = "SELECT contacts.* FROM contacts
            JOIN contact_client_links ON contacts.Contact_ID = contact_client_links.Contact_ID
            WHERE contact_client_links.Client_ID = '$client_id'
            ORDER BY contacts.Full_Name ASC"; // Assuming Full_Name is a column in your contacts table

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<p>" . $row['Full_Name'] . "</p>";
            // Add more columns as needed
        }
    } else {
        echo "No linked contacts found for the client";
    }
} else {
    echo "Invalid parameters for fetching linked contacts";
}

$conn->close();
?>
