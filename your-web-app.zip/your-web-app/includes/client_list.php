<?php
include('includes/db.php');
include('includes/db.php');
include 'client_list.php';
include 'subdirectory/client_list.php';
include __DIR__ . '/client_list.php';
include __DIR__ . DIRECTORY_SEPARATOR . 'client_list.php';


// Fetch and display client list from the database
$sql = "SELECT * FROM clients ORDER BY Name ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<p>" . $row['Name'] . "</p>";
        // Add more columns as needed
    }
} else {
    echo "No clients found";
}

$conn->close();
?>
