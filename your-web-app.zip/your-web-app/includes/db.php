<?php
// Increase memory limit
ini_set('memory_limit', '2048M');
set_time_limit(300); // Set to 300 seconds (5 minutes) or your desired value


// Other PHP code follows
include('includes/db.php');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Rest of your script...

$conn->close();

