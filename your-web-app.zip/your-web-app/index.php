<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Linked Clients</title>
        <link rel="stylesheet" href="styles.css">
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script src="javascripts.js"></script>
    </head>


<h2>Create New Contact</h2>
<form id="contactForm">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" required>
    <label for="surname">Surname:</label>
    <input type="text" id="surname" name="surname" required>
    <label for="email">Email address:</label>
    <input type="email" id="email" name="email" required>
    <label for="linkedClients">No. of Linked Clients:</label>
    <input type="number" id="linkedClients" name="linkedClients" required>
    <button type="button" onclick="createNewContact()">Create Contact</button>
</form>

<?php include 'get_contacts.php'; ?>


<h2>Contact Form</h2>

<div>
    <button onclick="openTab('generalTab')">General</button>
    <button onclick="openTab('linkClientsTab')">Link Clients</button>
</div>

<div id="generalTab" class="tabcontent">
    <h3>General</h3>
    <form id="generalForm">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        <label for="surname">Surname:</label>
        <input type="text" id="surname" name="surname" required>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <button type="button" onclick="submitGeneralForm()">Submit</button>
    </form>
</div>

<div id="linkClientsTab" class="tabcontent">
    <h3>Link Clients</h3>
    <!-- Add fields for linking clients here -->
</div>



<h2>Contact Management</h2>

<div>
    <button onclick="openTab('generalTab')">General</button>
    <button onclick="openTab('linkClientsTab')">Link Clients</button>
    <button onclick="openTab('clientTab')">Client(s)</button>
</div>

<!-- General Tab -->
<div id="generalTab" class="tabcontent">
    <h3>General</h3>
    <form id="generalForm">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        <label for="surname">Surname:</label>
        <input type="text" id="surname" name="surname" required>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <button type="button" onclick="submitGeneralForm()">Submit</button>
    </form>
</div>





<!-- Link Clients Tab -->
<div id="linkClientsTab" class="tabcontent">
    <h3>Link Clients</h3>
    <form id="linkClientsForm">
        <label for="clientName">Client Name:</label>
        <input type="text" id="clientName" name="clientName" required>
        <label for="clientCode">Client Code:</label>
        <input type="text" id="clientCode" name="clientCode" required>
        <button type="button" onclick="linkClient()">Link Client</button>
    </form>
</div>

<!-- Client(s) Tab -->
<div id="clientTab" class="tabcontent">
    <h3>Client(s)</h3>
    <?php include 'includes/get_linked_clients.php'; ?>
</div>




    <script src="script.js"></script>
</body>
</html>
