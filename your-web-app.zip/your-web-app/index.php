<!DOCTYPE html>
<html lang="en">
<head>
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clients View</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="javascripts.js"></script>
</head>

<body>
    <div id="navbar">
        <!-- Your navigation bar content goes here -->
    </div>

    <div id="clients-view">
        <button onclick="createNewClient()">Create New Client</button>
        <div id="client-list">
            <!-- Display list of clients here -->
            <?php include('includes/db.php'); ?>
            <?php include('client_list.php'); ?>
        </div>
        <div id="linked-contacts">
            <!-- Display linked contacts here -->
            <?php include('linked_contacts.php'); ?>
        </div>
    </div>

    <div id="contacts-view">
        <button onclick="createNewContact()">Create New Contact</button>
        <div id="contact-list">
            <!-- Display list of contacts here -->
            <?php include('contact_list.php'); ?>
        </div>
        <div id="linked-clients">
            <!-- Display linked clients here -->
            <?php include('linked_clients.php'); ?>
        </div>

        <form id="contact-form" action="create_contact.php" method="post">
            <!-- Tab Segregation -->
            <!-- ... Your existing HTML for tabs and fields ... -->
            <button type="submit">Submit</button>
        </form>
    </div>

    <!-- Your other HTML content -->

    <script src="js/javascript.js"></script>
</body>
</html>
