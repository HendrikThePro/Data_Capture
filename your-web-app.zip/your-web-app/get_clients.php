<?php
include 'db.php';

// Fetch clients from the database
$result = $conn->query("SELECT * FROM clients ORDER BY name ASC");

if ($result->num_rows > 0) {
    echo '<table>';
    echo '<tr><th>Name</th><th>Client Code</th><th>No. of linked contacts</th></tr>';
    while ($row = $result->fetch_assoc()) {
        $clientId = $row['id'];
        $clientCode = get_clients($row['name']);
        $linkedContactsCount = getLinkedContactsCount($clientId);

        echo '<tr>';
        echo '<td>' . $row['name'] . '</td>';
        echo '<td>' . $clientCode . '</td>';
        echo '<td>' . $linkedContactsCount . '</td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo '<p>No clients found.</p>';
}

$conn->close();


function getLinkedContactsCount($clientId) {
    // the logic below with your actual database query or any other data retrieval method
    // to get the number of linked contacts for the specified client ID
    //  number between 0 and 10 is generated.

    // have a database connection
    //$db = new mysqli("your_host", "your_username", "your_password", "your_database");

    // Check for a successful connection
    // if ($db->connect_error) {
    //     die("Connection failed: " . $db->connect_error);
    // }

    // Example query: this with your actual query
    // $query = "SELECT COUNT(*) FROM linked_contacts WHERE client_id = $clientId";

    // // Execute the query
    // $result = $db->query($query);

    // // Check for query success
    // if ($result) {
    //     $row = $result->fetch_assoc();
    //     $linkedContactsCount = $row['COUNT(*)'];
    // } else {
    //     // Handle query error
    //     $linkedContactsCount = 0;
    // }

    // generate a random number between 0 and 10
    $linkedContactsCount = rand(0, 10);

    // Close the database connection if opened
    // $db->close();

    return $linkedContactsCount;
}

// Example usage:
$clientId = 123; // Replace with the actual client ID
$linkedContactsCount = getLinkedContactsCount($clientId);
echo "Number of linked contacts for Client ID $clientId: $linkedContactsCount";
?>



function generateClientCode($name) {
    // Remove spaces and make the name uppercase
    $cleanedName = strtoupper(str_replace(' ', '', $name));

    // Take the first three characters of the name
    $shortName = substr($cleanedName, 0, 3);

    // Generate a random three-digit number
    $randomNumber = rand(100, 999);

    // Combine the short name and random number to form the client code
    $clientCode = $shortName . $randomNumber;

    return $clientCode;
}


// Example usage:
$clientName = "Example Client";
$clientCode = generateClientCode($clientName);
echo "Generated Client Code for '$clientName': $clientCode";
?>

function getLinkedContactsCount($clientId) {
    // logic to get the number of linked contacts for a client
    // 
    return rand(0, 10);
}
?>
