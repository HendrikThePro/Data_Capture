<?php
phpinfo();

