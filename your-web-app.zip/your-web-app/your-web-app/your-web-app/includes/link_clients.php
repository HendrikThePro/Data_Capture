<?php
include('includes/db.php');

// Link client to contact
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_id'], $_POST['client_id'])) {
    $contact_id = $_POST['contact_id'];
    $client_id = $_POST['client_id'];

    $linkClientSQL = "INSERT INTO linked_clients_contacts (client_id, contact_id) VALUES ('$client_id', '$contact_id')";
    $conn->query($linkClientSQL);
}

// Fetch linked clients for each contact
$sql = "SELECT cc.id as link_id, c.name as client_name, c.client_code, ct.name as contact_name
        FROM client_contacts cc
        JOIN clients c ON cc.client_id = c.id
        JOIN contacts ct ON cc.contact_id = ct.id
        ORDER BY ct.name ASC, c.name ASC";
$result = $conn->query($sql);
$linkedClients = $result->fetch_all(MYSQLI_ASSOC);
?>

<!-- link_clients.html -->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Linked Clients</title>
        <link rel="stylesheet" href="styles.css">
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script src="javascripts.js"></script>
    </head>
<body>
    <h1>Contact Form</h1>
    <div id="tabs">
        <ul>
            <li><a href="#general-tab">General</a></li>
            <li><a href="#clients-tab">Client(s)</a></li>
        </ul>

        <!-- General Tab -->
        <div id="general-tab">
            <form method="post" action="contacts.php">
                <label>Name: </label>
                <input type="text" name="name" required>
                <label>Surname: </label>
                <input type="text" name="surname" required>
                <label>Email: </label>
                <input type="email" name="email" required>
                <button type="submit">Create Contact</button>
            </form>
        </div>

        <!-- Clients Tab -->
        <div id="clients-tab">
            <?php if (empty($linkedClients)): ?>
                <p>No clients linked.</p>
            <?php else: ?>
                <table>
                    <tr>
                        <th>Contact Name</th>
                        <th>Client Name</th>
                        <th>Client Code</th>
                        <th>Action</th>
                    </tr>
                    <?php foreach ($linkedClients as $linkedClient): ?>
                        <tr>
                            <td><?= $linkedClient['contact_name'] ?></td>
                            <td><?= $linkedClient['client_name'] ?></td>
                            <td><?= $linkedClient['client_code'] ?></td>
                            <td>
                                <a href="https://www.bcity.me/" onclick="unlinkClient(<?= $linkedClient['link_id'] ?>)">Unlink</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
