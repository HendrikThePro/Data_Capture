
<?php
// get_clients.php

// Fetch clients from the database or any other data source
$clients = get_clients_from_database(); // Implement this function according to your needs

// Check if there are clients to display
if ($clients) {
    // Sort clients by Name ascending
    usort($clients, function ($a, $b) {
        return strcmp($a['name'], $b['name']);
    });

    // Display the table headers
    echo '<table>';
    echo '<thead>';
    echo '<tr>';
    echo '<th>Name</th>';
    echo '<th>Client code</th>';
    echo '<th>No. of linked contacts</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';

    // Loop through clients and display rows
    foreach ($clients as $client) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($client['name']) . '</td>';
        echo '<td>' . htmlspecialchars($client['clientCode']) . '</td>';
        echo '<td class="center">' . $client['linkedContacts'] . '</td>';
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
} else {
    // If no clients, display a message
    echo '<p>No client(s) found.</p>';
}




function generateClientCode($name) {
    // Remove spaces and make the name uppercase
    $cleanedName = strtoupper(str_replace(' ', '', $name));

    // Take the first three characters of the name
    $shortName = substr($cleanedName, 0, 3);

    // Generate a random three-digit number
    $randomNumber = rand(100, 999);

    // Combine the short name and random number to form the client code
    $clientCode = $shortName . $randomNumber;

    return $clientCode;
}


// Example usage:
$clientName = "Example Client";
$clientCode = generateClientCode($clientName);
echo "Generated Client Code for '$clientName': $clientCode";



//actual database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";

// Create a database connection
$your_database_connection = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$your_database_connection) {
    die("Connection failed: " . mysqli_connect_error());
}

function get_clients_from_database() {
    global $your_database_connection;

    //  ctual name of your clients table
    $query = "SELECT * FROM clients";

    // Execute the query
    $result = mysqli_query($your_database_connection, $query);

    if (!$result) {
        die('Error fetching clients: ' . mysqli_error($your_database_connection));
    }

    $clients = array();

    // Fetch clients as an associative array
    while ($row = mysqli_fetch_assoc($result)) {
        $clients[] = $row;
    }

    // Free the result set
    mysqli_free_result($result);

    return $clients;
}




