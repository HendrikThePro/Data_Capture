<?php
// create_contact.php

// Include your database connection
include('includes/db.php');

// Get data from the AJAX request
$name = $_POST['name'];
$surname = $_POST['surname'];
$email = $_POST['email'];
$linkedClients = $_POST['linkedClients'];

// Perform validation if needed

// Insert the new contact into the database
$insertQuery = "INSERT INTO contacts (name, surname, email, linked_clients) VALUES ('$name', '$surname', '$email', $linkedClients)";

if (mysqli_query($conn, $insertQuery)) {
    // Return a success message or data if needed
    echo json_encode(['success' => true, 'message' => 'Contact created successfully']);
} else {
    // Return an error message if the query fails
    echo json_encode(['success' => false, 'message' => 'Error creating contact: ' . mysqli_error($conn)]);
}

// Close the database connection
mysqli_close($conn);
?>
