<?php
include('includes/db.php');
include 'includes/client.php';

// Establish a database connection using PDO
$db = new PDO('mysql:host=localhost;dbname=db', 'root', '');

// Create an instance of the Client class with the database connection
$client = new client($db);

// ... Rest of your code ...


class client
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function createClient($name)
    {
        $clientCode = $this->generateClientCode();
        $stmt = $this->db->prepare('INSERT INTO clients (name, client_code) VALUES (:name, :client_code)');
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':client_code', $clientCode);
        $stmt->execute();
    }

    public function getAllClients()
    {
        $stmt = $this->db->prepare('SELECT * FROM clients ORDER BY name ASC');
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function generateClientCode()
    {
        // Implement your logic for generating a client code (e.g., unique identifier)
        return uniqid('CL');
    }
}

?>
