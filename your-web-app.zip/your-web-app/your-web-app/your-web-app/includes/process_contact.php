<?php

include('includes/db.php');


// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $surname = $_POST["surname"];
    $email = $_POST["email"];
    saveContact($conn, $name, $surname, $email);
    echo "Contact saved successfully!";
} else {
    echo "Invalid request!";
}

$conn->close();

function saveContact($conn, $name, $surname, $email) {
    $stmt = $conn->prepare("INSERT INTO contacts (name, surname, email) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $surname, $email);
    $stmt->execute();
    $stmt->close();
}
?>

