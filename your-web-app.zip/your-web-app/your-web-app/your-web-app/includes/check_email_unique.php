<?php
include('includes/db.php');

// Check if the email exists in the database
if (isset($_POST['email'])) {
    $email = $_POST['email'];

    try {
        // Perform your database query to check if the email is unique
        $query = "SELECT COUNT(*) AS count FROM contacts WHERE email = :email";
        $statement = $pdo->prepare($query);
        $statement->bindParam(':email', $email, PDO::PARAM_STR);
        $statement->execute();
        $result = $statement->fetch(PDO::FETCH_ASSOC);

        // Return JSON response
        header('Content-Type: application/json');
        echo json_encode(['unique' => ($result['count'] == 0)]);
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Error checking email uniqueness. Please try again.']);
    }
} else {
    // Return a generic error response if email parameter is not provided
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Email parameter not provided.']);
}
?>



<script>
// Function to check if the email is unique
function isEmailUnique(email) {
    var isUnique = false;

    // Make an AJAX request to the server-side script for email uniqueness check
    $.ajax({
        url: 'includes/check_email_unique.php', // Update the path accordingly
        type: 'POST',
        data: { email: email },
        success: function (response) {
            // Assuming the server responds with JSON containing a 'unique' property
            isUnique = response.unique;
        },
        error: function () {
            // Handle error if AJAX request fails
            alert('Error checking email uniqueness. Please try again.');
        }
    });

    return isUnique;
}

// Example usage
var email = $('#email').val(); // Assuming you have an input field with ID 'email'
if (isEmailUnique(email)) {
    alert('Email is unique!');
} else {
    alert('Email is not unique. Please choose another email.');
}
</script>

