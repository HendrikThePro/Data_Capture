<!-- get_linked_clients.php -->
<?php
// Placeholder script - Replace with actual logic to fetch linked clients

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";

// Establishing database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch linked clients (replace with your actual query)
$contactId = 123; // Replace with the actual contact ID
$sql = "SELECT * FROM client_contact_link WHERE contact_id = '$contactId'";
$result = $conn->query($sql);

// Display linked clients or "No clients found" if the result is empty
if ($result && $result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>Client Name</th><th>Client Code</th><th>Action</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['client_name']}</td>";
        echo "<td>{$row['client_code']}</td>";
        echo "<td><a href='unlink_client.php?client_id={$row['client_id']}'>Unlink</a></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No clients found.";
}

// Close the database connection
$conn->close();
?>

