<?php
// Your PHP code here
require('includes/db.php');
include('includes/check_email_unique.php');
$clientId = $_POST['clientId'];

?>


<!DOCTYPE html>
<html lang="en">

<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Linked Clients</title>
        <link rel="stylesheet" href="styles.css">
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script src="scripts.js"></script>
    </head>
    

        <h2>Clients</h2>
        
        <!-- Create a new client form -->
        <form action="index.php" method="POST">
            <label for="clientName">Client Name:</label>
            <input type="text" name="clientName" required>
            <label for="surname">Surname:</label>
            <input type="text" id="surname" name="surname" required>
            <label for="email">Email address:</label>
            <input type="email" id="email" name="email" required>
            <button type="submit">Create Client</button>
        </form>

        
        <?php if (!empty($clients)) : ?>
            <!-- Display list of clients -->
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Client Code</th>
                        <th>No. of Linked Contacts</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($clients as $client) : ?>
                        <tr>
                            <td><?php echo $client['name']; ?></td>
                            <td><?php echo $client['client_code']; ?></td>
                            <td><?php echo $client['linked_contacts']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p class="no-clients-msg">No client(s) found.</p>
        <?php endif; ?>




        <h2>Contact Form</h2>

        <div>
            <button onclick="openTab('generalTab')">General</button>
            <button onclick="openTab('linkClientsTab')">Link Clients</button>
        </div>

        <div id="generalTab" class="tabcontent">
            <h3>General</h3>
            <form id="generalForm">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
                <label for="surname">Surname:</label>
                <input type="text" id="surname" name="surname" required>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
                <button type="button" onclick="submitGeneralForm()">Submit</button>
                <button type="button" onclick="cancelGeneralForm()">Cancel</button>
            <div id="linkClientsTab" class="tabcontent">
                <h3>Link Clients</h3>
                <form id="linkClientsForm">
                    <label for="clientName">Client Name:</label>
                    <input type="text" id="clientName" name="clientName" required>
                    
                    <label for="clientCode">Client Code:</label>
                    <input type="text" id="clientCode" name="clientCode" required>
                    
                    <button type="button" onclick="linkClient()">Link Client</button>
                </form>
        </div>



        <h2>Contact Management</h2>

        <div>
            <button onclick="openTab('generalTab')">General</button>
            <button onclick="openTab('linkClientsTab')">Link Clients</button>
            <button onclick="openTab('clientTab')">Client(s)</button>
        </div>

        <!-- General Tab -->
        <div id="generalTab" class="tabcontent">
            <h3>General</h3>
            <form id="generalForm">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
                <label for="surname">Surname:</label>
                <input type="text" id="surname" name="surname" required>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
                <button type="button" onclick="submitGeneralForm()">Submit</button>
            </form>
        </div>


        <!-- Link Clients Tab -->
        <div id="linkClientsTab" class="tabcontent">
            <h3>Link Clients</h3>
            <form id="linkClientsForm">
                <label for="clientName">Client Name:</label>
                <input type="text" id="clientName" name="clientName" required>
                <label for="clientCode">Client Code:</label>
                <input type="text" id="clientCode" name="clientCode" required>
                <button type="button" onclick="linkClient()">Link Client</button>
            </form>

            <!-- Display Linked Clients Table -->
            <h3>Linked Clients</h3>
            <table id="linkedClientsTable">
                <thead>
                    <tr>
                        <th>Client Name</th>
                        <th>Client Code</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Linked clients will be dynamically added here -->
                </tbody>
            </table>
        </div>


    <script src="script.js"></script>
</body>
</html>
