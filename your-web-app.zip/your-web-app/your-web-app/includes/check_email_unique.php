<?php

// Assuming you have a database connection
include('includes/db.php');

// Check if the email exists in the database
if (isset($_POST['email'])) {
    $email = $_POST['email'];

    // Perform your database query to check if the email is unique
    $query = "SELECT COUNT(*) AS count FROM contacts WHERE email = :email";
    $statement = $pdo->prepare($query);
    $statement->bindParam(':email', $email, PDO::PARAM_STR);
    $statement->execute();
    $result = $statement->fetch(PDO::FETCH_ASSOC);

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode(['unique' => ($result['count'] == 0)]);
} else {
    // Return a generic error response if email parameter is not provided
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Email parameter not provided.']);
}

