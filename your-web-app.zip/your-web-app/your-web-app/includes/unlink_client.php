<?php
// Assuming you have a database connection established

// Check if the client ID is provided in the POST request
if (isset($_POST['clientId'])) {
    // Sanitize the input to prevent SQL injection (replace with your sanitization method)
    $clientId = intval($_POST['clientId']);

    // Perform the unlinking operation (replace with your actual logic)
    // This might involve updating database records or any other necessary operations

    // Example: Update the 'linked_clients' table
    $query = "DELETE FROM linked_clients_contacts WHERE client_id = :clientId";
    $statement = $pdo->prepare($query);
    $statement->bindParam(':clientId', $clientId, PDO::PARAM_INT);

    // Execute the query
    if ($statement->execute()) {
        // Unlinking successful
        $response = array('success' => true, 'message' => 'Client unlinked successfully');
    } else {
        // Unlinking failed
        $response = array('success' => false, 'message' => 'Error unlinking client');
    }
} else {
    // Client ID not provided in the POST request
    $response = array('success' => false, 'message' => 'Client ID not provided');
}

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);

