<?php
// Include your database connection or any necessary files
include('includes/db.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $email = $_POST['email'];

    // Perform validation if needed

    // Insert data into the database or perform other necessary actions
    $query = "INSERT INTO contacts (name, surname, email) VALUES ('$name', '$surname', '$email')";
    
    if (mysqli_query($conn, $query)) {
        // Success response
        echo json_encode(['success' => true, 'message' => 'Form submitted successfully']);
    } else {
        // Error response
        echo json_encode(['success' => false, 'message' => 'Error submitting form']);
    }

    // Close the database connection if needed
    mysqli_close($conn);
} else {
    // Handle invalid requests
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}

