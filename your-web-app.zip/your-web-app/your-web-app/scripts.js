
// scripts.js

function createNewClient() {
    var clientName = $('#clientName').val();
    // Add more fields as needed

    $.ajax({
        type: 'POST',
        url: 'create_client.php',
        data: { clientName: clientName },
        dataType: 'json',
        success: function (response) {
            if (response.success) {
                alert('Client created successfully');
                // Additional actions if needed
            } else {
                alert('Error: ' + response.message);
            }
        },
        error: function () {
            alert('Error: Unable to communicate with the server');
        }
    });
}

// Call createNewClient function when the "Create Client" button is clicked
$('#createClientBtn').on('click', function () {
    createNewClient();
});







// Function to link a client
function linkClient() {
    // Get the input values
    var clientName = $('#clientName').val();
    var clientCode = $('#clientCode').val();

    // AJAX request to link the client
    $.ajax({
        type: 'POST',
        url: 'includes/link_clients.php', // actual URL of your server-side script
        data: {
            clientName: clientName,
            clientCode: clientCode
        },
        dataType: 'json',
        success: function (response) {
            if (response.success) {
                alert('Client linked successfully');
                // Additional actions if needed
            } else {
                alert('Error: ' + response.message);
            }
        },
        error: function () {
            alert('Error: Unable to communicate with the server');
        }
    });
}



// Handle tab opening
function openTab(tabName) {
    // Get all elements with class "tabcontent" and hide them
    var tabContents = document.getElementsByClassName("tabcontent");
    for (var i = 0; i < tabContents.length; i++) {
        tabContents[i].style.display = "none";
    }

    // Get all elements with class "tab" and remove the "active" class
    var tabs = document.getElementsByClassName("tab");
    for (var i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove("active");
    }

    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(tabName).style.display = "block";
    document.querySelector('[onclick="openTab(\'' + tabName + '\')"]').classList.add("active");
}





// Handle general form submission
function submitGeneralForm() {
    // Get form data
    var formData = {
        name: document.getElementById('name').value,
        surname: document.getElementById('surname').value,
        email: document.getElementById('email').value,
    };

    // Make an AJAX request
    $.ajax({
        type: 'POST',
        url: 'includes/submit_general_form.php', // actual URL of your server-side script
        data: formData,
        success: function (response) {
            // Handle the success response
            console.log('Form submitted successfully:', response);
            // You can update the UI or perform other actions as needed
        },
        error: function (error) {
            // Handle the error response
            console.error('Error submitting form:', error);
            // You can display an error message or perform other actions as needed
        }
    });
}





// Document ready function
$(document).ready(function () {
    // Initialization logic here

    // Example: Attach click event to a button
    $('#submitButton').on('click', function () {
        // Call a function when the button is clicked
        submitGeneralForm();
    });

    // You can add more initialization logic as needed
});


// Handle tab opening
function openTab(tabName) {
    // Get all elements with class "tabcontent" and hide them
    var tabContents = document.getElementsByClassName("tabcontent");
    for (var i = 0; i < tabContents.length; i++) {
        tabContents[i].style.display = "none";
    }

    // Get all elements with class "tab" and remove the "active" class
    var tabs = document.getElementsByClassName("tab");
    for (var i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove("active");
    }

    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(tabName).style.display = "block";
    document.querySelector('[onclick="openTab(\'' + tabName + '\')"]').classList.add("active");
}

    


// Handle general form submission
function submitGeneralForm() {
    // Logic to handle general form submission

    // Example: Make an AJAX request
    $.ajax({
        url: 'includes/submit_general_form.php', // actual URL of your server-side script
        type: 'POST',
        data: $('#generalForm').serialize(), // Serialize form data
        dataType: 'json',
        success: function (response) {
            // Handle the server response
            if (response.success) {
                alert('Form submitted successfully');
            } else {
                alert('Error submitting form: ' + response.message);
            }
        },
        error: function () {
            alert('Error submitting form. Please try again.');
        }
    });
}





// Function to fetch and display linked clients
function displayLinkedClients() {
    // Assuming you have an API endpoint to fetch linked clients
    var apiEndpoint = '/api/getLinkedClients';

    // Make an AJAX request to fetch linked clients
    $.ajax({
        type: 'GET',
        url: apiEndpoint,
        success: function (data) {
            // Call a function to render the linked clients table
            renderLinkedClientsTable(data);
        },
        error: function (error) {
            console.error('Error fetching linked clients:', error);
        }
    });
}

// Function to render the linked clients table
function renderLinkedClientsTable(linkedClients) {
    var linkedClientsTable = $('#linkedClientsTable tbody');
    
    // Clear previous data
    linkedClientsTable.empty();

    // Check if there are linked clients
    if (linkedClients.length > 0) {
        // Loop through linked clients and append rows to the table
        linkedClients.forEach(function (client) {
            var row = '<tr>';
            row += '<td>' + client.clientName + '</td>';
            row += '<td>' + client.clientCode + '</td>';
            row += '<td><button onclick="unlinkClient(' + client.clientId + ')">Unlink</button></td>';
            row += '</tr>';
            linkedClientsTable.append(row);
        });
    } else {
        // If no linked clients, display a message
        linkedClientsTable.append('<tr><td colspan="3">No linked clients found</td></tr>');
    }
}

// Function to unlink a client
function unlinkClient(clientId) {
    // AJAX request to unlink the client
    $.ajax({
        type: 'POST',
        url: '/api/unlinkClient',
        data: { clientId: clientId },
        success: function (response) {
            // After unlinking, refresh the linked clients table
            displayLinkedClients();
            console.log('Client unlinked successfully.');
        },
        error: function (error) {
            console.error('Error unlinking client:', error);
        }
    });
}

// Call displayLinkedClients function when the document is ready
$(document).ready(function () {
    displayLinkedClients();
});






$(document).ready(function () {
    getClients();
    getContacts();

    $('#client-form').on('submit', function (event) {
        
        // Submit client form
    $('#clientForm').on('submit', function (event) {
        event.preventDefault();
        $.ajax({
            url: 'includes/process_client.php',
            type: 'POST',
            data: { clientName: $('#clientName').val() },
            success: function (response) {
                alert(response);
                getClients(); // Refresh clients list
            },
            error: function (error) {
                console.error('Error creating client:', error);
            }
        });
    });
    });

    $('#contact-form').on('submit', function (event) {
        // Contact form submission AJAX logic
    });




    function getClients() {
        // logic to fetch and display clients
        $.ajax({
            url: 'includes/process_client.php',
            type: 'GET',
            success: function (data) {
                displayClients(data);
            },
            error: function (error) {
                console.error('Error fetching clients:', error);
            }
        });
    }




    function getContacts() {
        // AJAX logic to fetch and display contacts
        $.ajax({
            url: 'includes/process_contact.php',
            type: 'GET',
            success: function (data) {
                displayContacts(data);
            },
            error: function (error) {
                console.error('Error fetching contacts:', error);
            }
        });
    }
});




function displayContacts(data) {
    var contactsTable = $('#contacts-list tbody');
    var noContactsMsg = $('#no-contacts-msg');

    // Clear previous data
    contactsTable.empty();

    if (data.length > 0) {
        // Loop through contacts and append rows to the table
        data.forEach(function (contact) {
            var fullName = contact.surname + ' ' + contact.name;
            var email = contact.email;

            var row = '<tr>';
            row += '<td>' + fullName + '</td>';
            row += '<td>' + email + '</td>';
            // Add an action URL for unlinking the contact (you need to implement this logic)
            row += '<td><a href="#" class="unlink-contact" data-contact-id="' + contact.id + '">Unlink</a></td>';
            row += '</tr>';

            contactsTable.append(row);
        });
    } else {
        // Display the "No contacts found" message
        noContactsMsg.show();
    }
}





// Function to create a new contact
function createContact() {
    // Validate and process the form data
    var name = document.getElementById('name').value;
    var surname = document.getElementById('surname').value;
    var email = document.getElementById('email').value;

    // Check for uniqueness of email (you may need to implement this on the server side)
    if (isEmailUnique(email)) {
        // Add your logic to create a new contact with the provided data
        console.log('Creating contact:', name, surname, email);
    } else {
        alert('Email address must be unique for each contact.');
    }
}



// Function to check if the email is unique
function isEmailUnique(email) {
    var isUnique = false;

    // Make an AJAX request to the server-side script for email uniqueness check
    $.ajax({
        url: 'includes/check_email_unique.php', //  actual URL of your server-side script
        type: 'POST',
        data: { email: email },
        async: false, // Ensure synchronous request for simplicity (consider using callbacks for asynchronous approach)
        success: function (response) {
            // Assuming the server responds with JSON containing a 'unique' property
            isUnique = response.unique;
        },
        error: function () {
            // Handle error if AJAX request fails
            alert('Error checking email uniqueness. Please try again.');
        }
    });

    return isUnique;
}

// Example usage
var email = $('#email').val(); // Assuming you have an input field with ID 'email'
if (isEmailUnique(email)) {
    alert('Email is unique!');
} else {
    alert('Email is not unique. Please choose another email.');
}




$(document).ready(function() {
    // This function runs when the document is ready

    // Log a message to the console for debugging
    console.log('Contacts JavaScript loaded.');

    // Perform an AJAX request to fetch data from 'contacts.php'
    $.ajax({
        url: 'includes/contacts.php',   // actual URL of your server-side script
        method: 'GET',         // Use the GET method
        dataType: 'json',      // Expect JSON as the response data type
        success: function(data) {
            // This function runs if the AJAX request is successful

            // Log the fetched data to the console for further inspection
            console.log('Contacts data:', data);

            // TODO: Update the UI with the fetched data
            // You would typically manipulate the DOM here to display the contacts on the page
        },
        error: function(error) {
            // This function runs if there's an error with the AJAX request

            // Log the error to the console for debugging
            console.error('Error fetching contacts:', error);

            // TODO: Handle the error - you might display an error message to the user
        }
    });
});




// link_clients.js
$(document).ready(function() {
    console.log('Link Clients JavaScript loaded.');

    // Example: Perform an AJAX request to unlink a client
    function unlinkClient(linkId) {
        $.ajax({
            url: 'includes/unlink_client.php',
            method: 'POST',
            data: { linkId: linkId },
            success: function(response) {
                console.log('Client unlinked successfully.');
                // TODO: Update the UI accordingly
            },
            error: function(error) {
                console.error('Error unlinking client:', error);
            }
        });
    }

    // Example: Attach click event to unlink a client
    $('.unlink-client-button').on('click', function() {
        var linkId = $(this).data('link-id');
        unlinkClient(linkId);
    });
});




