<?php
include 'config.php';

// Fetch contacts
$sql = "SELECT * FROM contacts ORDER BY name ASC";
$result = $conn->query($sql);
$contacts = $result->fetch_all(MYSQLI_ASSOC);

// Return data as JSON
header('Content-Type: application/json');
echo json_encode($contacts);
?>
