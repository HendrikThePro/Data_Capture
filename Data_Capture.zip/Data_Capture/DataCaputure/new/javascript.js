$(document).ready(function () {
    getClients();
    getContacts();

    $('#client-form').on('submit', function (event) {
        
        // Submit client form
    $('#clientForm').on('submit', function (event) {
        event.preventDefault();
        $.ajax({
            url: 'process_client.php',
            type: 'POST',
            data: { clientName: $('#clientName').val() },
            success: function (response) {
                alert(response);
                getClients(); // Refresh clients list
            },
            error: function (error) {
                console.error('Error creating client:', error);
            }
        });
    });
    });

    $('#contact-form').on('submit', function (event) {
        // Contact form submission AJAX logic
    });

    function getClients() {
        // logic to fetch and display clients
        $.ajax({
            url: 'process_client.php',
            type: 'GET',
            success: function (data) {
                displayClients(data);
            },
            error: function (error) {
                console.error('Error fetching clients:', error);
            }
        });
    }

    function getContacts() {
        // AJAX logic to fetch and display contacts
        $.ajax({
            url: 'process_contact.php',
            type: 'GET',
            success: function (data) {
                displayContacts(data);
            },
            error: function (error) {
                console.error('Error fetching contacts:', error);
            }
        });
    }
});

function displayContacts(data) {
    var contactsTable = $('#contacts-list tbody');
    var noContactsMsg = $('#no-contacts-msg');

    // Clear previous data
    contactsTable.empty();

    if (data.length > 0) {
        // Loop through contacts and append rows to the table
        data.forEach(function (contact) {
            var fullName = contact.surname + ' ' + contact.name;
            var email = contact.email;

            var row = '<tr>';
            row += '<td>' + fullName + '</td>';
            row += '<td>' + email + '</td>';
            // Add an action URL for unlinking the contact (you need to implement this logic)
            row += '<td><a href="#" class="unlink-contact" data-contact-id="' + contact.id + '">Unlink</a></td>';
            row += '</tr>';

            contactsTable.append(row);
        });
    } else {
        // Display the "No contacts found" message
        noContactsMsg.show();
    }
}


