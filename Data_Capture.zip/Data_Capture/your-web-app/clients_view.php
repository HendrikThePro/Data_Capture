<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clients View</title>
    <!-- Include necessary stylesheets and scripts -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Navigation bar or other common elements -->
    <div id="navbar">
        <!-- Your navigation bar content goes here -->
    </div>

    <!-- Clients View -->
    <div id="clients-view">
        <!-- New Client Creation -->
        <form action="create_client.php" method="post">
            <label for="name">Client Name:</label>
            <input type="text" id="name" name="name" required>
            <button type="submit">Create New Client</button>
        </form>

        <!-- Client List Display -->
        <div id="client-list">
            <?php
            include('includes/db.php');
            // Fetch and display clients
            $sql = "SELECT * FROM clients ORDER BY Name ASC"; // Assuming 'clients' is your clients table
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<p>" . $row['Name'] . "</p>"; // Adjust column names based on your table structure
                    // Add more columns as needed
                }
            } else {
                echo "No clients found";
            }

            $conn->close();
            ?>
        </div>

        <!-- Linked Contacts Display -->
        <div id="linked-contacts">
            <!-- Display linked contacts here -->
            <!-- Include unlink action URLs -->
        </div>
    </div>

    <!-- Your other HTML content -->

    <!-- Include JavaScript logic -->
    <script src="javascript.js"></script>
</body>
</html>


 
