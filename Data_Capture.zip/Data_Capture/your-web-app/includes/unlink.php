<?php
include('includes/db.php');
include('includes/db.php');
include 'client_list.php';
include 'subdirectory/client_list.php';
include __DIR__ . '/client_list.php';
include __DIR__ . DIRECTORY_SEPARATOR . 'client_list.php';


if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['contact_id']) && isset($_GET['client_id'])) {
    // Process the unlinking action
    $contact_id = $_GET['contact_id'];
    $client_id = $_GET['client_id'];

    // Assuming you have a linking table named contact_client_links
    $sql = "DELETE FROM contact_client_links WHERE Contact_ID = '$contact_id' AND Client_ID = '$client_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Unlinking successful";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Invalid parameters for unlinking";
}

$conn->close();
?>
