<?php
include('includes/db.php');
include 'client_list.php';
include 'subdirectory/client_list.php';
include __DIR__ . '/client_list.php';
include __DIR__ . DIRECTORY_SEPARATOR . 'client_list.php';


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

