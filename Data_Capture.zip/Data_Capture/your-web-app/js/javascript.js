$(document).ready(function () {
    getClients();
    getContacts();

    $('#client-form').on('submit', function (event) {
        
        // Submit client form
    $('#clientForm').on('submit', function (event) {
        event.preventDefault();
        $.ajax({
            url: 'process_client.php',
            type: 'POST',
            data: { clientName: $('#clientName').val() },
            success: function (response) {
                alert(response);
                getClients(); // Refresh clients list
            },
            error: function (error) {
                console.error('Error creating client:', error);
            }
        });
    });
    });

    $('#contact-form').on('submit', function (event) {
        // Contact form submission AJAX logic
    });

    function getClients() {
        // logic to fetch and display clients
        $.ajax({
            url: 'process_client.php',
            type: 'GET',
            success: function (data) {
                displayClients(data);
            },
            error: function (error) {
                console.error('Error fetching clients:', error);
            }
        });
    }

    function getContacts() {
        // AJAX logic to fetch and display contacts
        $.ajax({
            url: 'process_contact.php',
            type: 'GET',
            success: function (data) {
                displayContacts(data);
            },
            error: function (error) {
                console.error('Error fetching contacts:', error);
            }
        });
    }
});

function displayContacts(data) {
    var contactsTable = $('#contacts-list tbody');
    var noContactsMsg = $('#no-contacts-msg');

    // Clear previous data
    contactsTable.empty();

    if (data.length > 0) {
        // Loop through contacts and append rows to the table
        data.forEach(function (contact) {
            var fullName = contact.surname + ' ' + contact.name;
            var email = contact.email;

            var row = '<tr>';
            row += '<td>' + fullName + '</td>';
            row += '<td>' + email + '</td>';
            // Add an action URL for unlinking the contact (you need to implement this logic)
            row += '<td><a href="#" class="unlink-contact" data-contact-id="' + contact.id + '">Unlink</a></td>';
            row += '</tr>';

            contactsTable.append(row);
        });
    } else {
        // Display the "No contacts found" message
        noContactsMsg.show();
    }
}

// Define functions for creating clients and contacts, displaying lists, linking/unlinking, etc.
function createNewClient() {
    //  creating a new client
    function createNewClient() {
        // Assuming you are using XMLHttpRequest for simplicity
        var xhr = new XMLHttpRequest();
    
        // Define the endpoint to create a new client
        var endpoint = '/api/createNewClient';
    
        // Set up the request
        xhr.open('POST', endpoint, true);
        xhr.setRequestHeader('Content-Type', 'application/json');
    
        // You can customize the client data based on your form or requirements
        var newClientData = {
            name: 'New Client',  // Replace with the actual data from your form
            // Add other client details as needed
        };
    
        // Convert the data to JSON format
        var jsonData = JSON.stringify(newClientData);
    
        // Set up event handler for successful response
        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                // The client was created successfully
                alert('New client created successfully!');
                // You can update the client list or perform other actions here
            } else {
                // Handle the error if the request was not successful
                alert('Failed to create a new client. Please try again.');
            }
        };
    
        // Set up event handler for network errors
        xhr.onerror = function () {
            alert('Network error occurred. Please try again.');
        };
    
        // Send the request with the JSON data
        xhr.send(jsonData);
    }
    
}

// Add other functions for displaying lists, linking/unlinking, etc.

// Ensure uniqueness of email addresses for contacts
// ...

// Add event listeners and other necessary logic
// ...




document.addEventListener('DOMContentLoaded', function () {
    // Call the function to fetch and display the client list when the DOM is loaded
    displayClientList();
});

function displayClientList() {
    // Assuming you are using XMLHttpRequest for simplicity
    var xhr = new XMLHttpRequest();

    // Define the endpoint to fetch the client list
    var endpoint = '/api/getClientList';

    // Set up the request
    xhr.open('GET', endpoint, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    // Set up event handler for successful response
    xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
            // Parse the JSON response
            var clientList = JSON.parse(xhr.responseText);

            // Display the client list
            renderClientList(clientList);
        } else {
            // Handle the error if the request was not successful
            console.error('Failed to fetch client list.');
        }
    };

    // Set up event handler for network errors
    xhr.onerror = function () {
        console.error('Network error occurred while fetching client list.');
    };

    // Send the request
    xhr.send();
}

function renderClientList(clientList) {
    // Get the client-list div
    var clientListDiv = document.getElementById('client-list');

    // Clear any existing content
    clientListDiv.innerHTML = '';

    // Create a table to display the client list
    var table = document.createElement('table');
    table.border = '1';

    // Create table header
    var headerRow = table.insertRow();
    var nameHeader = headerRow.insertCell(0);
    nameHeader.innerHTML = 'Name';  // Add other headers as needed

    // Loop through the client list and create table rows
    for (var i = 0; i < clientList.length; i++) {
        var client = clientList[i];
        var row = table.insertRow();

        // Add client data to the row (replace with actual property names)
        var nameCell = row.insertCell(0);
        nameCell.innerHTML = client.name;  // Replace 'name' with the actual property name

        // Add other cells as needed
    }

    // Append the table to the client-list div
    clientListDiv.appendChild(table);
}


document.addEventListener('DOMContentLoaded', function () {
    // Call the function to fetch and display linked contacts when the DOM is loaded
    displayLinkedContacts();
});

function displayLinkedContacts() {
    // Replace 'clientId' with the actual ID of the client for which you want to fetch linked contacts
    var clientId = 123; // Replace with the actual client ID

    // Assuming you are using XMLHttpRequest for simplicity
    var xhr = new XMLHttpRequest();

    // Define the endpoint to fetch linked contacts
    var endpoint = '/api/getLinkedContacts?clientId=' + clientId;

    // Set up the request
    xhr.open('GET', endpoint, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    // Set up event handler for successful response
    xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
            // Parse the JSON response
            var linkedContacts = JSON.parse(xhr.responseText);

            // Display the linked contacts
            renderLinkedContacts(linkedContacts);
        } else {
            // Handle the error if the request was not successful
            console.error('Failed to fetch linked contacts.');
        }
    };

    // Set up event handler for network errors
    xhr.onerror = function () {
        console.error('Network error occurred while fetching linked contacts.');
    };

    // Send the request
    xhr.send();
}

function renderLinkedContacts(linkedContacts) {
    // Get the linked-contacts div
    var linkedContactsDiv = document.getElementById('linked-contacts');

    // Clear any existing content
    linkedContactsDiv.innerHTML = '';

    // Create a table to display the linked contacts
    var table = document.createElement('table');
    table.border = '1';

    // Create table header
    var headerRow = table.insertRow();
    var nameHeader = headerRow.insertCell(0);
    nameHeader.innerHTML = 'Full Name';  // Replace with the actual property name

    // Add other headers as needed

    // Loop through the linked contacts and create table rows
    for (var i = 0; i < linkedContacts.length; i++) {
        var contact = linkedContacts[i];
        var row = table.insertRow();

        // Add contact data to the row (replace with actual property names)
        var nameCell = row.insertCell(0);
        nameCell.innerHTML = contact.fullName;  // Replace 'fullName' with the actual property name

        // Add other cells as needed

        // Add action for unlinking contacts (replace 'unlinkContact' with your actual unlinking function)
        var unlinkCell = row.insertCell(1);
        var unlinkAction = document.createElement('a');
        unlinkAction.href = 'javascript:unlinkContact(' + contact.id + ')'; // Replace 'id' with the actual property name
        unlinkAction.innerText = 'Unlink';
        unlinkCell.appendChild(unlinkAction);
    }

    // Append the table to the linked-contacts div
    linkedContactsDiv.appendChild(table);
}

// Function to unlink a contact (replace with your actual unlinking logic)
function unlinkContact(contactId) {
    // Add your logic to unlink the contact with the provided contactId
    console.log('Unlinking contact with ID: ' + contactId);
}


document.addEventListener('DOMContentLoaded', function () {
    // Call the function to fetch and display linked clients when the DOM is loaded
    displayLinkedClients();
});

function displayLinkedClients() {
    // Replace 'contactId' with the actual ID of the contact for which you want to fetch linked clients
    var contactId = 456; // Replace with the actual contact ID

    // Assuming you are using XMLHttpRequest for simplicity
    var xhr = new XMLHttpRequest();

    // Define the endpoint to fetch linked clients
    var endpoint = '/api/getLinkedClients?contactId=' + contactId;

    // Set up the request
    xhr.open('GET', endpoint, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    // Set up event handler for successful response
    xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
            // Parse the JSON response
            var linkedClients = JSON.parse(xhr.responseText);

            // Display the linked clients
            renderLinkedClients(linkedClients);
        } else {
            // Handle the error if the request was not successful
            console.error('Failed to fetch linked clients.');
        }
    };

    // Set up event handler for network errors
    xhr.onerror = function () {
        console.error('Network error occurred while fetching linked clients.');
    };

    // Send the request
    xhr.send();
}

function renderLinkedClients(linkedClients) {
    // Get the linked-clients div
    var linkedClientsDiv = document.getElementById('linked-clients');

    // Clear any existing content
    linkedClientsDiv.innerHTML = '';

    // Create a table to display the linked clients
    var table = document.createElement('table');
    table.border = '1';

    // Create table header
    var headerRow = table.insertRow();
    var nameHeader = headerRow.insertCell(0);
    nameHeader.innerHTML = 'Client Name';  // Replace with the actual property name

    // Add other headers as needed

    // Loop through the linked clients and create table rows
    for (var i = 0; i < linkedClients.length; i++) {
        var client = linkedClients[i];
        var row = table.insertRow();

        // Add client data to the row (replace with actual property names)
        var nameCell = row.insertCell(0);
        nameCell.innerHTML = client.clientName;  // Replace 'clientName' with the actual property name

        // Add other cells as needed

        // Add action for unlinking clients (replace 'unlinkClient' with your actual unlinking function)
        var unlinkCell = row.insertCell(1);
        var unlinkAction = document.createElement('a');
        unlinkAction.href = 'javascript:unlinkClient(' + client.id + ')'; // Replace 'id' with the actual property name
        unlinkAction.innerText = 'Unlink';
        unlinkCell.appendChild(unlinkAction);
    }

    // Append the table to the linked-clients div
    linkedClientsDiv.appendChild(table);
}

// Function to unlink a client (replace with your actual unlinking logic)
function unlinkClient(clientId) {
    // Add your logic to unlink the client with the provided clientId
    console.log('Unlinking client with ID: ' + clientId);
}


// Function to show the selected tab
function showTab(tabId) {
    var tabs = document.getElementsByClassName('tab-content');
    for (var i = 0; i < tabs.length; i++) {
        tabs[i].style.display = 'none';
    }

    document.getElementById(tabId).style.display = 'block';
}

// Function to create a new contact
function createContact() {
    // Validate and process the form data
    var name = document.getElementById('name').value;
    var surname = document.getElementById('surname').value;
    var email = document.getElementById('email').value;

    // Check for uniqueness of email (you may need to implement this on the server side)
    if (isEmailUnique(email)) {
        // Add your logic to create a new contact with the provided data
        console.log('Creating contact:', name, surname, email);
    } else {
        alert('Email address must be unique for each contact.');
    }
}

// Function to check if the email is unique (replace with your actual logic)
function isEmailUnique(email) {
    // Add your logic to check email uniqueness on the server side
    // For simplicity, assume email is always unique in this example
    return true;
}
// contacts.js
// TODO: JavaScript logic for contact interactions
// contacts.js
$(document).ready(function() {
    // TODO: JavaScript logic for contact interactions
    console.log('Contacts JavaScript loaded.');

    // Example: Perform an AJAX request to fetch data
    $.ajax({
        url: 'contacts.php',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            console.log('Contacts data:', data);
            // TODO: Update the UI with the fetched data
        },
        error: function(error) {
            console.error('Error fetching contacts:', error);
        }
    });
});
// link_clients.js
function unlinkClient(linkId) {
    // Implement logic to handle unlinking client (e.g., send AJAX request)
    console.log('Unlink client with ID:', linkId);
}

// link_clients.js
$(document).ready(function() {
    console.log('Link Clients JavaScript loaded.');

    // Example: Perform an AJAX request to unlink a client
    function unlinkClient(linkId) {
        $.ajax({
            url: 'unlink_client.php',
            method: 'POST',
            data: { linkId: linkId },
            success: function(response) {
                console.log('Client unlinked successfully.');
                // TODO: Update the UI accordingly
            },
            error: function(error) {
                console.error('Error unlinking client:', error);
            }
        });
    }

    // Example: Attach click event to unlink a client
    $('.unlink-client-button').on('click', function() {
        var linkId = $(this).data('link-id');
        unlinkClient(linkId);
    });
});




