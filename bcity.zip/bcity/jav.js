// JavaScript for actions
document.getElementById('clientForm').addEventListener('submit', function(event) {
    event.preventDefault();
    // Link contacts, generate client code, etc.
  });
  
  document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    // Link clients, validate email, etc.
  });
  