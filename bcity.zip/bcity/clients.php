<?php
include 'config.php';

// Create a new client
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['client_name'])) {
    $client_name = $_POST['client_name'];
    $client_code = $_POST['client_code'];

    $sql = "INSERT INTO clients (name, client_code) VALUES ('$client_name', '$client_code')";
    $conn->query($sql);
}

// Fetch clients
$sql = "SELECT * FROM clients ORDER BY name ASC";
$result = $conn->query($sql);
$clients = $result->fetch_all(MYSQLI_ASSOC);
?>

<!-- clients.html -->
<html>
<head>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="clients.js"></script>
</head>
<body>
    <h1>Clients</h1>
    <form method="post" action="clients.php">
        <label>Name: </label>
        <input type="text" name="client_name" required>
        <label>Client Code: </label>
        <input type="text" name="client_code" required>
        <button type="submit">Create Client</button>
    </form>

    <?php if (empty($clients)): ?>
        <p>No client(s) found.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>Name</th>
                <th>Client Code</th>
                <th>No. of linked contacts</th>
            </tr>
            <?php foreach ($clients as $client): ?>
                <tr>
                    <td><?= $client['name'] ?></td>
                    <td><?= $client['client_code'] ?></td>
                    <td>TODO: No. of linked contacts</td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</body>
</html>
