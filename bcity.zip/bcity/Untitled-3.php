<?php
// Database connection
$db = new mysqli('localhost', 'username', 'password', 'database');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Create a new contact
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $email = $_POST['email'];
    $query = "INSERT INTO contacts (name, surname, email) VALUES ('$name', '$surname', '$email')";
    mysqli_query($db, $query);
}

// Fetch all contacts
$query = "SELECT name, surname, email, COUNT(clients.id) as num_clients FROM contacts LEFT JOIN clients ON contacts.id = clients.contact_id GROUP BY contacts.id ORDER BY surname ASC, name ASC";
$result = mysqli_query($db, $query);
$contacts = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Close connection
mysqli_close($db);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Contacts</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <h1>Contacts</h1>
    <table>
        <thead>
            <tr>
                <th style="text-align: left;">Name</th>
                <th style="text-align: left;">Surname</th>
                <th style="text-align: left;">Email Address</th>
                <th style="text-align: center;">No. of Linked Clients</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($contacts) > 0): ?>
                <?php foreach ($contacts as $contact): ?>
                    <tr>
                        <td style="text-align: left;"><?php echo $contact['name']; ?></td>
                        <td style="text-align: left;"><?php echo $contact['surname']; ?></td>
                        <td style="text-align: left;"><?php echo $contact['email']; ?></td>
                        <td style="text-align: center;"><?php echo $contact['num_clients']; ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" style="text-align: center;">No contact(s) found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
