<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $clientName = $_POST["clientName"];

    $stmt = $conn->prepare("INSERT INTO clients (name) VALUES (?)");
    $stmt->bind_param("s", $clientName);
    $stmt->execute();

    echo "Client created successfully!";
} else {
    echo "Invalid request!";
}

$conn->close();
?>
