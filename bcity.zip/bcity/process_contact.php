<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $contactName = $_POST["contactName"];
    $contactSurname = $_POST["contactSurname"];
    $contactEmail = $_POST["contactEmail"];

    $stmt = $conn->prepare("INSERT INTO contacts (name, surname, email) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $contactName, $contactSurname, $contactEmail);
    $stmt->execute();

    echo "Contact created successfully!";
} else {
    echo "Invalid request!";
}

$conn->close();
?>
