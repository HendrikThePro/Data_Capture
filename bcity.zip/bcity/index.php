<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clients View</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="scripts.js"></script>
</head>

<body>

    <h2>Clients</h2>

    <!-- Create a new client form -->
    <form id="clientForm">
        <label for="clientName">Client Name:</label>
        <input type="text" id="clientName" required>
        <button type="submit">Create Client</button>
    </form>

    <!-- Display list of clients -->
    <div id="clientsTableContainer"></div>

</body>

</html>
