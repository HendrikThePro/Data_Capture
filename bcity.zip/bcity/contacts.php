<?php
include 'config.php';

// Create a new contact
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'])) {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $email = $_POST['email'];

    // Validate email uniqueness
    $checkUnique = "SELECT * FROM contacts WHERE email = '$email'";
    $result = $conn->query($checkUnique);
    
    if ($result->num_rows > 0) {
        // Email is not unique, handle accordingly (e.g., display error)
    } else {
        $createContactSQL = "INSERT INTO contacts (name, surname, email) VALUES ('$name', '$surname', '$email')";
        $conn->query($createContactSQL);
    }
}

// Fetch contacts
$sql = "SELECT * FROM contacts ORDER BY name ASC";
$result = $conn->query($sql);
$contacts = $result->fetch_all(MYSQLI_ASSOC);
?>

<!-- contacts.html -->
<html>
<head>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="contacts.js"></script>
</head>
<body>
    <h1>Contacts</h1>
    <form method="post" action="contacts.php">
        <label>Name: </label>
        <input type="text" name="name" required>
        <label>Surname: </label>
        <input type="text" name="surname" required>
        <label>Email: </label>
        <input type="email" name="email" required>
        <button type="submit">Create Contact</button>
    </form>

    <?php if (empty($contacts)): ?>
        <p>No contact(s) found.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>Name</th>
                <th>Surname</th>
                <th>Email</th>
                <th>No. of linked clients</th>
            </tr>
            <?php foreach ($contacts as $contact): ?>
                <tr>
                    <td><?= $contact['name'] ?></td>
                    <td><?= $contact['surname'] ?></td>
                    <td><?= $contact['email'] ?></td>
                    <td>TODO: No. of linked clients</td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</body>
</html>
