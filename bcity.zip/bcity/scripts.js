$(document).ready(function () {
    // Load clients on page load
    getClients();

    // Submit client form
    $('#clientForm').on('submit', function (event) {
        event.preventDefault();
        $.ajax({
            url: 'process_client.php',
            type: 'POST',
            data: { clientName: $('#clientName').val() },
            success: function (response) {
                alert(response);
                getClients(); // Refresh clients list
            },
            error: function (error) {
                console.error('Error creating client:', error);
            }
        });
    });

    // Function to fetch and display clients
    function getClients() {
        $.ajax({
            url: 'get_clients.php',
            type: 'GET',
            success: function (data) {
                $('#clientsTableContainer').html(data);
            },
            error: function (error) {
                console.error('Error fetching clients:', error);
            }
        });
    }
});
