<?php
include 'db.php';

$result = $conn->query("SELECT * FROM contacts ORDER BY surname, name ASC");

if ($result->num_rows > 0) {
    echo '<table>';
    echo '<tr><th>Name</th><th>Surname</th><th>Email</th><th>No. of linked clients</th></tr>';
    while ($row = $result->fetch_assoc()) {
        $contactId = $row['id'];
        $linkedClientsCount = getLinkedClientsCount($contactId);

        echo '<tr>';
        echo '<td>' . $row['name'] . '</td>';
        echo '<td>' . $row['surname'] . '</td>';
        echo '<td>' . $row['email'] . '</td>';
        echo '<td>' . $linkedClientsCount . '</td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo '<p>No contacts found.</p>';
}

$conn->close();

function getLinkedClientsCount($contactId) {
    // logic to get the number of linked clients for a contact
    //  specific requirements
    return rand(0, 10);
}
?>
