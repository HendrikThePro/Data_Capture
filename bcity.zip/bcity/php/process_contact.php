<?php
include 'db.php';

function saveContact($name, $surname, $email) {
    // Implement contact saving logic here
    $stmt = $conn->prepare("INSERT INTO contacts (name, surname, email) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $surname, $email);
    $stmt->execute();

    $stmt->close();
}

function linkClientsToContact($contactId, $linkedClients) {
    // Implement linking clients to contact logic here
    foreach ($linkedClients as $clientId) {
        $stmt = $conn->prepare("INSERT INTO client_contact_link (client_id, contact_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $clientId, $contactId);
        $stmt->execute();
        $stmt->close();
    }
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $contactName = $_POST["name"];
    $contactSurname = $_POST["surname"];
    $contactEmail = $_POST["email"];
    $linkedClients = isset($_POST["linkedClients"]) ? $_POST["linkedClients"] : [];

    saveContact($contactName, $contactSurname, $contactEmail);

    $contactId = $conn->insert_id;
    linkClientsToContact($contactId, $linkedClients);

    echo "Contact saved successfully!";
} else {
    echo "Invalid request!";
}

$conn->close();
?>
