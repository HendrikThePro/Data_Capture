<?php
include 'db.php';

// Fetch contacts from the database
$result = $conn->query("SELECT * FROM contacts ORDER BY name ASC");

if ($result->num_rows > 0) {
    echo '<table>';
    echo '<tr><th>Name</th><th>Surname</th><th>Email</th><th>No. of linked clients</th></tr>';
    while ($row = $result->fetch_assoc()) {
        $contactId = $row['id'];
        $linkedClientsCount = getLinkedClientsCount($contactId);

        echo '<tr>';
        echo '<td>' . $row['name'] . '</td>';
        echo '<td>' . $row['surname'] . '</td>';
        echo '<td>' . $row['email'] . '</td>';
        echo '<td>' . $linkedClientsCount . '</td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo 'No contacts found.';
}

function getLinkedClientsCount($contactId) {
    global $conn;

    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM client_contact_link WHERE contact_id = ?");
    $stmt->bind_param("i", $contactId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    return $row['count'];
}

$stmt->close();
$conn->close();
?>
