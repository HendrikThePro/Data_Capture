<?php
include 'db.php';

// Fetch clients from the database
$result = $conn->query("SELECT * FROM clients ORDER BY name ASC");

if ($result->num_rows > 0) {
    echo '<table>';
    echo '<tr><th>Name</th><th>Client Code</th><th>No. of linked contacts</th></tr>';
    while ($row = $result->fetch_assoc()) {
        $clientId = $row['id'];
        $linkedContactsCount = getLinkedContactsCount($clientId);

        echo '<tr>';
        echo '<td>' . $row['name'] . '</td>';
        echo '<td>' . $row['client_code'] . '</td>';
        echo '<td>' . $linkedContactsCount . '</td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo 'No clients found.';
}

function getLinkedContactsCount($clientId) {
    global $conn;

    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM client_contact_link WHERE client_id = ?");
    $stmt->bind_param("i", $clientId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    return $row['count'];
}

$stmt->close();
$conn->close();
?>
