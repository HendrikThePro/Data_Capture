// scripts.js

// Wait for the DOM to be ready
$(document).ready(function () {

    // Function to fetch and display clients
    function getClients() {
        $.ajax({
            url: 'get_clients.php', // Replace with the actual server-side script
            type: 'GET',
            success: function (data) {
                $('#client-list').html(data);
            },
            error: function (error) {
                console.error('Error fetching clients:', error);
            }
        });
    }

    // Function to fetch and display contacts
    function getContacts() {
        $.ajax({
            url: 'get_contacts.php', // Replace with the actual server-side script
            type: 'GET',
            success: function (data) {
                $('#contact-list').html(data);
            },
            error: function (error) {
                console.error('Error fetching contacts:', error);
            }
        });
    }

    // Initial load of clients and contacts
    getClients();
    getContacts();

    // Event listener for client form submission
    $('#client-form').on('submit', function (event) {
        event.preventDefault();
        
        $.ajax({
            url: 'process_client.php', // Replace with the actual server-side script
            type: 'POST',
            data: $(this).serialize(),
            success: function (response) {
                getClients(); // Refresh client list after successful submission
            },
            error: function (error) {
                console.error('Error submitting client form:', error);
            }
        });
    });

    // Event listener for contact form submission
    $('#contact-form').on('submit', function (event) {
        event.preventDefault();

        $.ajax({
            url: 'process_contact.php', // Replace with the actual server-side script
            type: 'POST',
            data: $(this).serialize(),
            success: function (response) {
                getContacts(); // Refresh contact list after successful submission
            },
            error: function (error) {
                console.error('Error submitting contact form:', error);
            }
        });
    });

    $('#contact-form').on('submit', function (event) {
        event.preventDefault();

        $.ajax({
            url: 'process_contact.php',
            type: 'POST',
            data: $(this).serialize(),
            success: function (response) {
                getContacts();
            },
            error: function (error) {
                console.error('Error submitting contact form:', error);
            }
        });
    });
});

//*