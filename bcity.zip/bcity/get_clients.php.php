<?php
include 'db.php';

$result = $conn->query("SELECT * FROM clients ORDER BY name ASC");

if ($result->num_rows > 0) {
    echo '<table>';
    echo '<tr><th>Name</th><th>Client Code</th><th>No. of linked contacts</th></tr>';
    while ($row = $result->fetch_assoc()) {
        $clientId = $row['id'];
        $clientCode = generateClientCode($row['name']);
        $linkedContactsCount = getLinkedContactsCount($clientId);

        echo '<tr>';
        echo '<td>' . $row['name'] . '</td>';
        echo '<td>' . $clientCode . '</td>';
        echo '<td>' . $linkedContactsCount . '</td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo '<p>No clients found.</p>';
}

$conn->close();

function generateClientCode($name) {
    // Implement client code generation logic here
    
    return strtoupper(substr($name, 0, 3)) . rand(100, 999);
}

function getLinkedContactsCount($clientId) {
    // logic to get the number of linked contacts for a client
    // This is a placeholder; 
    return rand(0, 10);
}
?>
