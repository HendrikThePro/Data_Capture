<?php
include 'db.php';

// Functions: generateClientCode, saveClient, linkContactsToClient, getUniqueNumericPart

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $clientName = $_POST["name"];
    $linkedContacts = isset($_POST["linkedContacts"]) ? $_POST["linkedContacts"] : [];

    $generatedClientCode = generateClientCode($clientName);
    saveClient($clientName, $generatedClientCode);

    $clientId = $conn->insert_id;
    linkContactsToClient($clientId, $linkedContacts);

    echo "Client saved successfully!";
} else {
    echo "Invalid request!";
}


function generateClientCode($name) {
    // Implement client code generation logic here
    // This function should return the generated client code
    // You can adapt the logic based on your requirements
    $alphaPart = strtoupper(substr($name, 0, 3));
    $numericPart = getUniqueNumericPart();
    return $alphaPart . str_pad($numericPart, 3, '0', STR_PAD_LEFT);
}

function saveClient($name, $clientCode) {
    // Implement client saving logic here
    $stmt = $conn->prepare("INSERT INTO clients (name) VALUES (?)");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    
    $clientId = $stmt->insert_id;

    // Save client code in the client_codes table
    $stmt = $conn->prepare("INSERT INTO client_codes (client_id, code) VALUES (?, ?)");
    $stmt->bind_param("is", $clientId, $clientCode);
    $stmt->execute();
    
    $stmt->close();
}

function linkContactsToClient($clientId, $linkedContacts) {
    // Implement linking contacts to client logic here
    foreach ($linkedContacts as $contactId) {
        $stmt = $conn->prepare("INSERT INTO client_contact_link (client_id, contact_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $clientId, $contactId);
        $stmt->execute();
        $stmt->close();
    }
}

// Get a unique numeric part for the client code
function getUniqueNumericPart() {
    global $conn;
    
    $stmt = $conn->prepare("SELECT MAX(CAST(SUBSTRING(code, 4) AS UNSIGNED)) AS max_numeric FROM client_codes");
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    $uniqueNumericPart = ($row['max_numeric'] !== null) ? $row['max_numeric'] + 1 : 1;

    $stmt->close();

    return $uniqueNumericPart;
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $clientName = $_POST["name"];
    $linkedContacts = isset($_POST["linkedContacts"]) ? $_POST["linkedContacts"] : [];

    $generatedClientCode = generateClientCode($clientName);
    saveClient($clientName, $generatedClientCode);

    $clientId = $conn->insert_id;
    linkContactsToClient($clientId, $linkedContacts);

    echo "Client saved successfully!";
} else {
    echo "Invalid request!";
}

$conn->close();
$conn->close();
?>
