<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clients View</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>

    <h2>Clients</h2>

    <!-- Create a new client form -->
    <form action="process_client.php" method="POST">
        <label for="clientName">Client Name:</label>
        <input type="text" name="clientName" required>
        <button type="submit">Create Client</button>
    </form>

    <!-- Display list of clients -->
    <?php include 'get_clients.php'; ?>

    class Client {
    public function createClient($name) {
        // Implement client creation logic here
    }

    public function getAllClients() {
        // Implement fetching all clients ordered by Name
    }

    // Add other methods as needed
}

// Usage Example
$client = new Client();
$clients = $client->getAllClients();
?>

<!-- Client View -->
<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Client Code</th>
            <th>No. of Linked Contacts</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($clients as $client) : ?>
            <tr>
                <td><?php echo $client['name']; ?></td>
                <td><?php echo $client['client_code']; ?></td>
                <td><?php echo $client['linked_contacts']; ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Client Form -->
<form action="process_client.php" method="post">
    <!-- Form fields and tabs as described -->
</form>


class Contact {
    public function createContact($name, $surname, $email) {
        // Implement contact creation logic here
    }

    public function getAllContacts() {
        // Implement fetching all contacts ordered by Full Name
    }

    // Add other methods as needed
}

// Usage Example
$contact = new Contact();
$contacts = $contact->getAllContacts();
?>

<!-- Contact View -->
<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Surname</th>
            <th>Email Address</th>
            <th>No. of Linked Clients</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($contacts as $contact) : ?>
            <tr>
                <td><?php echo $contact['name']; ?></td>
                <td><?php echo $contact['surname']; ?></td>
                <td><?php echo $contact['email']; ?></td>
                <td><?php echo $contact['linked_clients']; ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Contact Form -->
<form action="process_contact.php" method="post">
    <!-- Form fields and tabs as described -->
</form>









</body>

</html>
