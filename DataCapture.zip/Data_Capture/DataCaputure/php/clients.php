<?php
include 'config.php';

// Fetch clients
$sql = "SELECT * FROM clients ORDER BY name ASC";
$result = $conn->query($sql);
$clients = $result->fetch_all(MYSQLI_ASSOC);

// Return data as JSON
header('Content-Type: application/json');
echo json_encode($clients);
?>
